import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Plus, Minus, ShoppingCart } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useCart } from '@/contexts/CartContext';
import { formatPrice } from '@/data/products';
import { useNavigate } from 'react-router-dom';
import ProductPriceDisplay from '@/components/ProductPriceDisplay';

const CartSidebar = () => {
  const { cartItems, isOpen, setIsOpen, updateQuantity, removeFromCart, getTotalPrice } = useCart();
  const navigate = useNavigate();

  const handleCheckout = () => {
    setIsOpen(false);
    navigate('/checkout');
  };
 
  const CartIcon = ShoppingCart; 

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setIsOpen(false)}
            className="fixed inset-0 bg-black/50 z-50"
            aria-hidden="true"
          />
          
          <motion.div
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ type: 'spring', damping: 25, stiffness: 200 }}
            className="fixed right-0 top-0 h-full w-full max-w-md bg-gray-900 border-l border-white/20 z-50 flex flex-col"
            role="dialog"
            aria-modal="true"
            aria-labelledby="cart-sidebar-title"
          >
            <div className="flex items-center justify-between p-4 border-b border-white/20">
              <h2 id="cart-sidebar-title" className="text-xl font-bold text-white flex items-center gap-2">
                <CartIcon className="h-5 w-5" strokeWidth={2} />
                سلة التسوق
              </h2>
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setIsOpen(false)}
                className="text-white hover:bg-white/10"
                aria-label="Close shopping cart"
              >
                <X className="h-5 w-5" strokeWidth={2}/>
              </Button>
            </div>

            <div className="flex-1 overflow-y-auto p-4">
              {cartItems.length === 0 ? (
                <div className="text-center text-white/60 mt-8">
                  <CartIcon className="h-16 w-16 mx-auto mb-4 opacity-50" strokeWidth={1.5} />
                  <p>السلة فارغة</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {cartItems.map((item) => (
                    <motion.div
                      key={item.id}
                      layout
                      className="glass-effect rounded-lg p-4"
                    >
                      <div className="flex gap-3">
                        <img
                          src={item.main_image_url || 'https://via.placeholder.com/100'}
                          alt={item.name}
                          className="w-16 h-16 object-cover rounded-lg"
                        />
                        <div className="flex-1">
                          <h3 className="text-white font-medium text-sm mb-1">
                            {item.name}
                          </h3>
                          <ProductPriceDisplay
                            price={item.price}
                            discountedPrice={item.discounted_price}
                            finalPriceClassName="text-purple-300 font-bold text-sm"
                            originalPriceClassName="text-white/40 text-xs line-through mr-1"
                            discountTextClassName="text-green-400 text-xs ml-1"
                          />
                          <div className="flex items-center justify-between mt-2">
                            <div className="flex items-center gap-2">
                              <Button
                                variant="ghost"
                                size="icon"
                                onClick={() => updateQuantity(item.id, item.quantity - 1)}
                                className="h-8 w-8 text-white hover:bg-white/10"
                                aria-label={`Decrease quantity of ${item.name}`}
                              >
                                <Minus className="h-4 w-4" strokeWidth={2} />
                              </Button>
                              <span className="text-white w-8 text-center" aria-live="polite">
                                {item.quantity}
                              </span>
                              <Button
                                variant="ghost"
                                size="icon"
                                onClick={() => updateQuantity(item.id, item.quantity + 1)}
                                className="h-8 w-8 text-white hover:bg-white/10"
                                aria-label={`Increase quantity of ${item.name}`}
                                disabled={item.quantity >= item.stock}
                              >
                                <Plus className="h-4 w-4" strokeWidth={2} />
                              </Button>
                            </div>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => removeFromCart(item.id)}
                              className="text-red-400 hover:text-red-300 hover:bg-red-500/10"
                              aria-label={`Remove ${item.name} from cart`}
                            >
                              حذف
                            </Button>
                          </div>
                           {item.quantity >= item.stock && (
                              <p className="text-red-400 text-xs mt-1">الحد الأقصى للكمية المتاحة</p>
                           )}
                        </div>
                      </div>
                    </motion.div>
                  ))}
                </div>
              )}
            </div>

            {cartItems.length > 0 && (
              <div className="p-4 border-t border-white/20">
                <div className="flex justify-between items-center mb-4">
                  <span className="text-white font-bold">المجموع:</span>
                  <span className="text-purple-300 font-bold text-lg">
                    {formatPrice(getTotalPrice())}
                  </span>
                </div>
                <Button
                  onClick={handleCheckout}
                  className="w-full gradient-bg hover:opacity-90 text-white font-bold"
                >
                  إتمام الطلب
                </Button>
              </div>
            )}
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
};

export default CartSidebar;
