import React from 'react';
import { motion } from 'framer-motion';
import { formatPrice } from '@/data/products';

const OrderSummary = ({ items = [], subtotal }) => {
  const deliveryCost = {
    baghdad: 5000,
    other: 10000
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="glass-effect rounded-lg p-6"
    >
      <h3 className="text-xl font-bold text-white mb-4">ملخص الطلب</h3>
      
      <div className="space-y-4 mb-6">
        {items.map((item) => (
          <div key={item.id} className="flex justify-between items-center">
            <div className="flex items-center gap-2">
              <span className="text-white/80">{item.quantity} x</span>
              <span className="text-white">{item.name}</span>
            </div>
            <span className="text-white font-medium">
              {formatPrice(item.price * item.quantity)}
            </span>
          </div>
        ))}
      </div>

      <div className="border-t border-white/10 pt-4 mb-4">
        <div className="flex justify-between mb-2">
          <span className="text-white/60">المجموع الفرعي:</span>
          <span className="text-white">{formatPrice(subtotal)}</span>
        </div>
      </div>

      <div className="border-t border-white/10 pt-4 mb-4">
        <div className="text-center mb-4 p-4 bg-yellow-400/20 border border-yellow-500 rounded-lg">
          <h4 className="text-xl font-bold text-yellow-300 mb-2">تكلفة التوصيل:</h4>
          <div className="space-y-2 font-bold">
            <p className="text-yellow-200">بغداد: {formatPrice(deliveryCost.baghdad)}</p>
            <p className="text-yellow-200">المحافظات الأخرى: {formatPrice(deliveryCost.other)}</p>
          </div>
        </div>
      </div>
    </motion.div>
  );
};

export default OrderSummary;