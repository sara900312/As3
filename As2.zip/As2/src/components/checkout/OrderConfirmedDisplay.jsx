import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Copy, X as CloseIcon } from 'lucide-react';

const OrderConfirmedDisplay = ({ isOpen, orderCode, onCopy, onClose }) => {
  return (
    <AnimatePresence>
      {isOpen && (
         <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: 50 }}
          className="fixed bottom-4 right-4 md:bottom-8 md:right-8 bg-gradient-to-br from-purple-600 to-blue-700 p-6 rounded-xl shadow-2xl z-50 w-full max-w-sm text-white"
        >
          <Button 
            variant="ghost" 
            size="icon" 
            className="absolute top-2 right-2 text-white/70 hover:text-white hover:bg-white/10"
            onClick={onClose}
          >
            <CloseIcon className="h-5 w-5" />
          </Button>
          <h3 className="text-lg font-bold mb-2">تم تأكيد طلبك بنجاح!</h3>
          <p className="text-sm mb-1">رقم الطلب الخاص بك هو:</p>
          <div className="flex items-center justify-between bg-black/30 p-3 rounded-lg mb-4">
            <span className="font-mono text-yellow-300 text-lg tracking-wider">{orderCode}</span>
            <Button
              size="sm"
              variant="secondary"
              onClick={onCopy}
              className="bg-yellow-400 hover:bg-yellow-500 text-black"
            >
              <Copy className="h-4 w-4 mr-2" />
              نسخ
            </Button>
          </div>
          <p className="text-xs text-white/80">
            يمكنك الآن متابعة التسوق أو إغلاق هذه النافذة.
          </p>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

export default OrderConfirmedDisplay;