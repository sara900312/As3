import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/button';

const ConfirmationModal = ({ isOpen, countdown, orderCode, onCancel, onConfirmImmediately }) => {
  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 bg-black/70 z-50 flex items-center justify-center p-4"
        >
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.9, opacity: 0 }}
            className="glass-effect rounded-2xl p-8 max-w-md w-full text-center"
          >
            <div className="text-6xl mb-4 text-purple-300">{countdown}</div>
            <h3 className="text-white text-xl font-bold mb-2">
              تأكيد الطلب
            </h3>
            <p className="text-white/80 mb-2">
              رقم طلبك المؤقت: <span className="font-bold text-yellow-300">{orderCode}</span>
            </p>
                        <p className="text-white/70 mb-6">
              لا تغلق هذه النافذة لتأكيد طلبك. سيتم إرسال الطلب تلقائياً.
            </p>
            <div className="flex gap-3 justify-center">
              <Button
                onClick={onCancel}
                variant="outline"
                className="border-red-500/50 text-red-400 hover:bg-red-500/10"
              >
                إلغاء الطلب
              </Button>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

export default ConfirmationModal;
