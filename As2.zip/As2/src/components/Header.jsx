import React, { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import {
  ShoppingCart,
  Menu,
  X,
  Phone,
  Mail,
  Facebook,
  Instagram,
  Youtube,
  Warehouse,
  Bell,
  Lock,
  LogOut,
} from "lucide-react";
import TikTokIcon from "@/components/icons/TikTokIcon";
import { Button } from "@/components/ui/button";
import { useCart } from "@/contexts/CartContext";
import { useTheme } from "@/contexts/ThemeContext";
import { useSupabase } from "@/contexts/SupabaseContext";
import { useAuth } from "@/contexts/AuthContext";
import CartSidebar from "@/components/CartSidebar";
import { toast } from "@/components/ui/use-toast";

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isContactOpen, setIsContactOpen] = useState(false);
  const [contactDetails, setContactDetails] = useState({
    phone: "",
    email: "",
  });
  const [socialLinks, setSocialLinks] = useState([]);
  const { getTotalItems, setIsOpen: setCartOpen } = useCart();
  const { isDark } = useTheme();
  const { supabase } = useSupabase();
  const { user, signOut } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    const fetchContactInfo = async () => {
      if (!supabase) return;
      try {
        const { data, error } = await supabase
          .from("contact_info")
          .select("*")
          .eq("is_active", true)
          .order("display_order", { ascending: true });

        if (error) throw error;

        const phoneInfo = data.find((item) => item.type === "phone");
        const emailInfo = data.find((item) => item.type === "email");
        const socials = data.filter(
          (item) => item.type === "social"
        );

        setContactDetails({
          phone: phoneInfo ? phoneInfo.value : "+964 770 123 4567",
          email: emailInfo ? emailInfo.value : "info@neomart.iq",
        });
        setSocialLinks(socials);
      } catch (error) {
        console.error("Error fetching contact info:", error);
      }
    };
    fetchContactInfo();
  }, [supabase]);

  const handleInventoryClick = () => {
    if (user) {
      navigate("/inventory");
    } else {
      navigate("/ahmedloginwith3non");
    }
  };

  const handleLogout = async () => {
    await signOut();
    toast({ title: "تم تسجيل الخروج بنجاح" });
    navigate("/");
  };

  const menuItems = [
    { name: "الرئيسية", nameEn: "Home", path: "/" },
    { name: "المنتجات", nameEn: "Products", path: "/products" },
    { name: "معالجات", nameEn: "CPUs", path: "/products/cpu" },
    { name: "كروت رسوميات", nameEn: "Graphics Cards", path: "/products/gpu" },
    { name: "ذاكرة", nameEn: "RAM", path: "/products/ram" },
    { name: "تخزين", nameEn: "Storage", path: "/products/storage" },
    { name: "لوحات أم", nameEn: "Motherboards", path: "/products/motherboard" },
    { name: "شاشات", nameEn: "Monitors", path: "/products/monitor" },
    { name: "مزودات طاقة", nameEn: "Power Supplies", path: "/products/psu" },
    { name: "لابتوبات", nameEn: "Laptops", path: "/products/laptops" },
    { name: "إكسسوارات", nameEn: "Accessories", path: "/products/accessories" },
    { name: "الموبايلات", nameEn: "Mobile Phones", path: "/products/mobiles" },
  ];

  const mobileOnlyMenuItems = [
    { name: "الرئيسية", nameEn: "Home", path: "/" },
    {
      name: "تواصل معنا",
      nameEn: "Contact Us",
      action: () => {
        setIsContactOpen((prev) => !prev);
        setIsMenuOpen(false);
      },
    },
  ];

  const categoryMenuItems = menuItems.filter(
    (item) => item.path.startsWith("/products/") || item.path === "/products",
  );

  const getSocialIcon = (iconField, titleField) => {
    const iconProps = {
      className: "h-6 w-6 transition-transform hover:scale-110",
      strokeWidth: 1.5,
    };

    // Use icon field first, fallback to title for backward compatibility
    const iconName = (iconField || titleField || '').toLowerCase();

    if (iconName.includes("tiktok")) return <TikTokIcon {...iconProps} />;
    if (iconName.includes("facebook")) return <Facebook {...iconProps} />;
    if (iconName.includes("instagram")) return <Instagram {...iconProps} />;
    if (iconName.includes("youtube")) return <Youtube {...iconProps} />;
    if (iconName.includes("email") || iconName.includes("gmail"))
      return <Mail {...iconProps} />;
    return null;
  };

  const handleContactClick = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setIsContactOpen((prev) => !prev);
  };

  const headerTextColorClass = isDark ? "text-white" : "text-black";
  const headerButtonBgClass = isDark
    ? "hover:bg-white/10"
    : "hover:bg-black/10";
  const headerTextMutedColorClass = isDark ? "text-white/80" : "text-black/80";
  const headerHoverTextClass = isDark ? "hover:text-white" : "hover:text-black";

  return (
    <>
      <div className="bg-gradient-to-r from-purple-600 to-blue-500 text-white text-center py-1 text-sm font-semibold">
        <p>مرحباً بكم في متجرنا</p>
      </div>
      <header
        className={`glass-effect border-b ${isDark ? "border-white/20" : "border-black/20"} sticky top-0 z-40`}
      >
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between h-16">
            <div className="flex-1 flex items-center justify-start gap-2">
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setCartOpen(true)}
                className={`relative header-button-override ${headerTextColorClass} ${headerButtonBgClass} p-2`}
                aria-label="Open shopping cart"
              >
                <ShoppingCart className="h-6 w-6" strokeWidth={2} />
                {getTotalItems() > 0 && (
                  <span
                    className={`absolute top-0 right-0 transform translate-x-1/3 -translate-y-1/3 bg-purple-600 text-xs rounded-full h-5 w-5 flex items-center justify-center font-bold text-white border-2 border-gray-800`}
                  >
                    {getTotalItems()}
                  </span>
                )}
              </Button>
            </div>

            <div className="flex-1 flex justify-center">
              <Link to="/" className="flex flex-col items-center">
                <h1 className="text-2xl font-bold text-gradient">NEOMART</h1>
              </Link>
            </div>

            <div className="flex-1 flex items-center justify-end gap-2">
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setIsMenuOpen(!isMenuOpen)}
                className={`md:hidden ${headerTextColorClass} ${headerButtonBgClass}`}
                aria-label="Open menu"
              >
                {isMenuOpen ? (
                  <X className="h-6 w-6" strokeWidth={2} />
                ) : (
                  <Menu className="h-6 w-6" strokeWidth={2} />
                )}
              </Button>
            </div>
          </div>

          <nav
            className={`hidden md:flex items-center justify-center gap-4 text-sm ${headerTextMutedColorClass} pb-2`}
          >
            <Link
              to="/"
              className={`${headerHoverTextClass} transition-colors`}
            >
              الصفحة الرئيسية
            </Link>
            <span>|</span>
            <Link
              to="/products"
              className={`${headerHoverTextClass} transition-colors`}
            >
              الفئات
            </Link>
            <span>|</span>
            <button
              onClick={handleContactClick}
              className={`${headerHoverTextClass} transition-colors`}
            >
              تواصل معنا
            </button>
          </nav>

          <AnimatePresence>
            {isContactOpen && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: "auto" }}
                exit={{ opacity: 0, height: 0 }}
                className={`overflow-hidden border-t ${isDark ? "border-white/20" : "border-black/20"}`}
              >
                <div className={`py-6 text-center ${headerTextColorClass}`}>
                  <div className="flex flex-col md:flex-row justify-center items-center gap-6 mb-6">
                    <div className="flex items-center gap-3">
                      <Phone className="h-5 w-5" strokeWidth={1.5} />
                      <span>{contactDetails.phone}</span>
                    </div>
                    <a
                      href={`mailto:${contactDetails.email}`}
                      className="flex items-center gap-3 hover:text-purple-300 transition-colors"
                    >
                      <Mail className="h-5 w-5" strokeWidth={1.5} />
                      <span>{contactDetails.email}</span>
                    </a>
                  </div>
                  <div className="flex justify-center gap-6">
                    {socialLinks.map((social) => (
                      <motion.a
                        key={social.id}
                        href={social.url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className={`text-white/90 hover:text-purple-300 transition-all duration-300 hover:-translate-y-1`}
                        style={{
                          filter: 'drop-shadow(1px 1px 3px rgba(255, 255, 255, 0.7))'
                        }}
                        aria-label={social.title}
                        whileHover={{ scale: 1.1 }}
                        whileTap={{ scale: 0.95 }}
                      >
                        {getSocialIcon(social.icon, social.title)}
                      </motion.a>
                    ))}
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          <AnimatePresence>
            {isMenuOpen && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: "auto" }}
                exit={{ opacity: 0, height: 0 }}
                className={`md:hidden overflow-hidden border-t ${isDark ? "border-white/20" : "border-black/20"}`}
              >
                <nav className="py-2">
                  {mobileOnlyMenuItems.map((item, index) =>
                    item.path ? (
                      <Link
                        key={index}
                        to={item.path}
                        onClick={() => setIsMenuOpen(false)}
                        className={`block px-4 py-3 ${headerTextColorClass} ${headerButtonBgClass} transition-colors`}
                      >
                        {item.name}
                      </Link>
                    ) : (
                      <button
                        key={index}
                        onClick={item.action}
                        className={`block w-full text-right px-4 py-3 ${headerTextColorClass} ${headerButtonBgClass} transition-colors`}
                      >
                        {item.name}
                      </button>
                    ),
                  )}
                  <div className={`px-4 py-2 text-white/60 text-sm`}>
                    الفئات
                  </div>
                  {categoryMenuItems.map((item, index) => (
                    <Link
                      key={`cat-${index}`}
                      to={item.path}
                      onClick={() => setIsMenuOpen(false)}
                      className={`block pl-8 pr-4 py-3 ${headerTextColorClass} ${headerButtonBgClass} transition-colors`}
                    >
                      {item.name}
                    </Link>
                  ))}
                </nav>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </header>
      <CartSidebar />
    </>
  );
};

export default Header;
