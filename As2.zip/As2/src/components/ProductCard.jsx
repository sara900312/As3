import React from "react";
import { motion } from "framer-motion";
import { ShoppingCart, Eye } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useCart } from "@/contexts/CartContext";
import { formatPrice, getDiscountedPrice } from "@/data/products";
import { useNavigate } from "react-router-dom";
import ProductPriceDisplay from "@/components/ProductPriceDisplay";
import { getProductUrl } from "@/lib/slugUtils";

const ProductCard = ({ product, index = 0 }) => {
  const { addToCart } = useCart();
  const navigate = useNavigate();

  if (!product) {
    return null;
  }

  const handleViewProduct = () => {
    navigate(getProductUrl(product));
  };

  // حساب الأسعار والخصومات بشكل صحيح
  const originalPrice = product.price;

  // تحديد ما إذا كان المنتج مخفض حقاً
  const isProductDiscounted = product.is_discounted === true || (product.discount_percent && product.discount_percent > 0);

  // إذا كان discounted_price موجود، فهو السعر النهائي، وإلا فهو السعر الأصلي
  const finalPrice = isProductDiscounted && product.discounted_price ? product.discounted_price : originalPrice;
  const discountAmount = isProductDiscounted ? Math.max(0, originalPrice - finalPrice) : 0;
  const discountPercentage = isProductDiscounted && discountAmount > 0 && originalPrice > 0 ? Math.round((discountAmount / originalPrice) * 100) :
                           (isProductDiscounted && product.discount_percent ? product.discount_percent : 0);
  const hasDiscount = isProductDiscounted && (discountAmount > 0 || discountPercentage > 0);

  const mainImage =
    product.main_image_url ||
    "https://via.placeholder.com/300x200?text=No+Image";

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.05 }}
      className="product-card glass-effect rounded-xl overflow-hidden hover-lift group flex flex-col h-full shadow-lg hover:shadow-2xl transition-all duration-300 border border-white/10 hover:border-white/20 mobile-card-height"
    >
      <div className="relative overflow-hidden bg-white flex justify-center items-center p-0 m-0 border-b border-white/20">
        <img
          src={mainImage}
          alt={product.name}
          className="product-image relative z-10 block w-auto h-auto max-w-full max-h-full group-hover:scale-105 transition-all duration-300 drop-shadow-xl filter group-hover:brightness-110"
        />

        {hasDiscount && (
          <div
            className="absolute top-2 left-2 bg-gradient-to-r from-red-600 to-red-500 text-white px-3 py-1.5 rounded-lg text-sm font-bold z-10 shadow-xl"
            style={{
              backgroundColor: "rgba(123, 33, 33, 1)",
              border: "1px hidden rgba(255, 150, 150, 1)"
            }}
          >
            <div className="flex items-center gap-1">
              <span className="text-xs">💥</span>
              <span>خصم {discountPercentage}%</span>
            </div>
          </div>
        )}

        {product.is_featured && (
          <div className="absolute top-2 right-2 bg-blue-500 text-white px-2 py-1 rounded-full text-xs font-bold z-10">
            محدودة
          </div>
        )}

        {product.stock === 0 && (
          <div className="absolute top-2 right-2 bg-gray-700 text-white px-2 py-1 rounded-full text-xs font-bold">
            نفد المخزون
          </div>
        )}

        <div className="absolute inset-0 bg-white/80 opacity-0 group-hover:opacity-100 transition-all duration-300 flex items-center justify-center gap-2 p-2">
          <Button
            variant="secondary"
            size="sm"
            onClick={handleViewProduct}
            className="bg-gray-100 text-gray-700 hover:bg-gray-200 text-xs sm:text-sm px-2 sm:px-3 border border-gray-300"
          >
            <Eye className="h-3 w-3 sm:h-4 sm:w-4 mr-1" strokeWidth={2} />
            <span className="hidden sm:inline">عرض</span>
            <span className="sm:hidden">عرض</span>
          </Button>
          <Button
            variant="secondary"
            size="sm"
            onClick={() => addToCart(product)}
            className={`${hasDiscount ? 'bg-green-600 hover:bg-green-700' : 'bg-purple-600 hover:bg-purple-700'} text-white text-xs sm:text-sm px-2 sm:px-3 shadow-md`}
            disabled={product.stock === 0}
          >
            <ShoppingCart
              className="h-3 w-3 sm:h-4 sm:w-4 mr-1"
              strokeWidth={2}
            />
            <span className="hidden sm:inline">
              {product.stock === 0 ? "نفد" : "إضافة"}
            </span>
            <span className="sm:hidden">
              {product.stock === 0 ? "نفد" : "+"}
            </span>
          </Button>
        </div>
      </div>

      <div className="p-4 flex flex-col flex-grow">
        <div className="flex items-start justify-between mb-3">
          <h3 className="product-title text-white font-semibold leading-tight flex-1" title={product.name}>
            {product.name}
          </h3>
          <span className="text-white/40 text-xs ml-2">⯆</span>
        </div>

        {/* Product description removed for cleaner card design */}

        <div className="mb-3">
          <ProductPriceDisplay
            price={originalPrice}
            discountedPrice={hasDiscount ? finalPrice : 0}
            finalPriceClassName={hasDiscount ? "text-green-400 font-bold text-lg" : "text-purple-300 font-bold text-lg"}
            originalPriceClassName="text-white/50 text-base line-through"
            discountTextClassName="neon-discount-text text-sm font-semibold"
          />
        </div>

        <div className="flex items-center justify-between mb-3 pt-2 border-t border-white/10">
          <div className="flex items-center gap-1">
            <span className="text-white/50 text-xs bg-white/5 px-1.5 py-0.5 rounded flex items-center gap-1 sm:px-2 sm:py-1">
              <span className="hidden sm:inline">🏷️</span>
              <span className="hidden sm:inline">كود: </span>
              <span className="sm:hidden">#</span>
              <span className="sm:hidden text-[10px]">{product.barcode?.substring(0, 6) || 'N/A'}</span>
              <span className="hidden sm:inline">{product.barcode}</span>
            </span>
          </div>
          <span className="text-white/60 text-xs flex items-center gap-1">
            <span>📦</span>
            <span className="hidden sm:inline">متوفر: {product.stock}</span>
            <span className="sm:hidden">{product.stock}</span>
          </span>
        </div>

        <div className="flex flex-col sm:flex-row gap-2 mt-auto">
          <Button
            onClick={() => addToCart(product)}
            className="flex-1 gradient-bg hover:opacity-90 text-white font-medium py-2 px-3 transition-all duration-200 sm:py-2.5 sm:px-4"
            disabled={product.stock === 0}
          >
            <ShoppingCart className="h-4 w-4 mr-1 sm:mr-2" strokeWidth={2} />
            <span className="truncate text-sm sm:text-base">
              {product.stock === 0 ? "نفد المخزون" : "إضافة للسلة"}
            </span>
          </Button>
          <Button
            onClick={handleViewProduct}
            variant="outline"
            className="border-white/30 text-white hover:bg-white/10 hover:border-white/50 font-medium py-2 px-3 min-w-[70px] transition-all duration-200 sm:py-2.5 sm:px-4 sm:min-w-[80px]"
          >
            <Eye className="h-4 w-4 mr-1" strokeWidth={2} />
            <span className="text-sm sm:text-base">عرض</span>
          </Button>
        </div>
      </div>
    </motion.div>
  );
};

export default ProductCard;
