import React from 'react';
import { formatPrice } from '@/data/products';

const ProductPriceDisplay = ({ 
  price, 
  discountedPrice = 0, 
  className = "", 
  originalPriceClassName = "text-gray-500 line-through text-sm mr-2",
  finalPriceClassName = "text-red-500 font-bold",
  discountTextClassName = "text-green-600 text-sm ml-2"
}) => {
  // التحقق من صحة البيانات
  if (!price || price <= 0) {
    return <span className={className}>غير متوفر</span>;
  }

  // إذا كان discountedPrice موجود وأقل من price، فهو السعر النهائي
  const finalPrice = (discountedPrice && discountedPrice > 0 && discountedPrice < price) ? discountedPrice : price;
  const hasDiscount = discountedPrice && discountedPrice > 0 && discountedPrice < price;

  return (
    <div className={`flex items-center flex-wrap ${className}`}>
      {hasDiscount ? (
        <>
          {/* السعر الأصلي مع خط */}
          <span
            className={originalPriceClassName}
            style={{
              textShadow: "1px 1px 4px rgba(177, 74, 77, 1)",
              fontSize: "15px"
            }}
          >
            {formatPrice(price)}
          </span>

          {/* السعر بعد الخصم */}
          <span
            className={finalPriceClassName}
            style={{
              textShadow: "1px 1px 3px rgba(100, 211, 177, 1)"
            }}
          >
            {formatPrice(finalPrice)}
          </span>
        </>
      ) : (
        /* السعر العادي بدون خصم */
        <span className={finalPriceClassName}>
          {formatPrice(price)}
        </span>
      )}
    </div>
  );
};

export default ProductPriceDisplay;
