import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Facebook, Instagram, Youtube, Mail } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { toast } from '@/components/ui/use-toast';
import { useSupabase } from '@/contexts/SupabaseContext';
import TikTokIcon from '@/components/icons/TikTokIcon';

const Footer = () => {
  const [email, setEmail] = useState('');
  const [isSubscribing, setIsSubscribing] = useState(false);
  const [expandedPolicy, setExpandedPolicy] = useState(null);
  const [policies, setPolicies] = useState([]);
  const [contactInfo, setContactInfo] = useState([]);
  const { supabase } = useSupabase();

  useEffect(() => {
    const fetchFooterData = async () => {
      if (!supabase) return;
      try {
        const [policiesResponse, contactResponse] = await Promise.all([
          supabase.from('policies').select('*').eq('is_active', true),
          supabase.from('contact_info').select('*').eq('is_active', true).filter('type', 'eq', 'social').order('display_order', { ascending: true })
        ]);

        if (policiesResponse.error) throw policiesResponse.error;
        if (contactResponse.error) throw contactResponse.error;

        setPolicies(policiesResponse.data || []);
        setContactInfo(contactResponse.data || []);
      } catch (error) {
        console.error('Error fetching footer data:', error);
      }
    };

    fetchFooterData();
  }, [supabase]);

  const validateEmail = (email) => {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(String(email).toLowerCase());
  };

  const handleNewsletterSubmit = async (e) => {
    e.preventDefault();
    if (!validateEmail(email)) {
      toast({ title: "بريد إلكتروني غير صالح", description: "يرجى إدخال عنوان بريد إلكتروني صالح.", variant: "destructive" });
      return;
    }
    setIsSubscribing(true);
    
    try {
      const { data: existingSubscriber, error: checkError } = await supabase
        .from('subscribers')
        .select('email')
        .eq('email', email)
        .maybeSingle();

      if (checkError) throw checkError;

      if (existingSubscriber) {
        toast({ title: "أنت مشترك بالفعل!", description: "هذا البريد الإلكتروني موجود في قائمتنا البريدية.", variant: "default" });
        setEmail('');
        return;
      }

      const { error: insertError } = await supabase
        .from('subscribers')
        .insert({ email: email });

      if (insertError) throw insertError;
      
      toast({
        title: "تم الاشتراك بنجاح!",
        description: "شكراً لك على انضمامك لنشرتنا الإخبارية.",
      });
      setEmail('');

    } catch (error) {
      console.error('Subscription error:', error);
      toast({
        title: "خطأ في الاشتراك",
        description: "لم نتمكن من إضافتك. يرجى المحاولة مرة أخرى.",
        variant: "destructive",
      });
    } finally {
      setIsSubscribing(false);
    }
  };

  const getSocialIcon = (iconField, titleField) => {
    const iconProps = { className: "h-6 w-6", strokeWidth: 2 };

    // Use icon field first, fallback to title for backward compatibility
    const iconName = (iconField || titleField || '').toLowerCase();

    if (iconName.includes('tiktok')) return <TikTokIcon {...iconProps} />;
    if (iconName.includes('instagram')) return <Instagram {...iconProps} />;
    if (iconName.includes('facebook')) return <Facebook {...iconProps} />;
    if (iconName.includes('youtube')) return <Youtube {...iconProps} />;
    if (iconName.includes('email') || iconName.includes('gmail')) return <Mail {...iconProps} />;
    return null;
  };

  return (
    <footer className="glass-effect border-t border-white/20 mt-16">
      <div className="container mx-auto px-4 py-8">
        <div className="text-center mb-8">
          <h3 className="text-white text-xl font-bold mb-4">
            اشترك في نشرتنا الإخبارية - كن أول من يعرف عن المنتجات الجديدة والعروض الحصرية
          </h3>
          <form onSubmit={handleNewsletterSubmit} className="flex gap-2 max-w-md mx-auto">
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="أدخل بريدك الإلكتروني"
              className="flex-1 px-4 py-2 rounded-lg bg-white/10 border border-white/20 text-white placeholder-white/60 focus:outline-none focus:ring-2 focus:ring-purple-500"
              required
              disabled={isSubscribing}
            />
            <Button type="submit" className="gradient-bg hover:opacity-90 text-white" disabled={isSubscribing}>
              {isSubscribing ? 'جاري الاشتراك...' : 'اشتراك'}
            </Button>
          </form>
        </div>

        <div className="flex justify-center gap-6 mb-8">
          {contactInfo.map((social) => (
              <a
                key={social.id}
                href={social.url}
                target="_blank"
                rel="noopener noreferrer"
                className="text-white hover:text-purple-300 transition-colors"
                aria-label={social.title}
              >
                {getSocialIcon(social.icon, social.title)}
              </a>
            ))}
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          {policies.map((policy) => (
            <div key={policy.id}>
              <button
                onClick={() => setExpandedPolicy(expandedPolicy === policy.id ? null : policy.id)}
                className="text-white hover:text-purple-300 transition-colors font-medium text-right w-full"
              >
                {policy.title}
              </button>
              <AnimatePresence>
                {expandedPolicy === policy.id && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: 'auto' }}
                    exit={{ opacity: 0, height: 0 }}
                    className="mt-2 text-white/70 text-sm overflow-hidden"
                  >
                    {policy.content}
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          ))}
        </div>

        <div className="text-center text-white/60 text-sm border-t border-white/20 pt-4">
          <span>© {new Date().getFullYear()} NEOMART. جميع الحقوق محفوظة.</span>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
