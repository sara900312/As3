import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ShoppingCart, Share2, Minus, Plus, ArrowLeft } from 'lucide-react';
import { Button } from '@/components/ui/button';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import ProductCard from '@/components/ProductCard';
import { useCart } from '@/contexts/CartContext';
import { formatPrice, getDiscountedPrice } from '@/data/products';
import { useSupabase } from '@/contexts/SupabaseContext';
import ProductPriceDisplay from '@/components/ProductPriceDisplay';
import { toast } from '@/components/ui/use-toast';
import { getProductSlug, generateShortSlug, generateCategorySlug, generateCleanProductName } from '@/lib/slugUtils';

const ProductDetailPage = () => {
  const { slug, category, cleanName } = useParams();
  const navigate = useNavigate();
  const { addToCart } = useCart();
  const [product, setProduct] = useState(null);
  const [mainImage, setMainImage] = useState('');
  const [quantity, setQuantity] = useState(1);
  const [relatedProducts, setRelatedProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const { supabase } = useSupabase();
  const [allProductImages, setAllProductImages] = useState([]);

  useEffect(() => {
    const fetchProductAndRelated = async () => {
      if ((!slug && (!category || !cleanName)) || !supabase) {
        setLoading(false);
        return;
      }
      setLoading(true);
      try {
        let productData = null;

        // New URL structure: /product/{category}/{cleanName}
        if (category && cleanName) {
          const { data: allProducts, error: allProductsError } = await supabase
            .from('products')
            .select('*');

          if (!allProductsError && allProducts) {
            productData = allProducts.find(p => {
              const productCategory = generateCategorySlug(p.category_en || p.category);
              const productCleanName = p.url_name || generateCleanProductName(p);

              return productCategory === category && productCleanName === cleanName;
            });
          }
        }

        // Fallback: Old URL structure with slug
        if (!productData && slug) {
          // First try to find by slug
          let { data: slugProductData, error: productError } = await supabase
            .from('products')
            .select('*')
            .eq('slug', slug)
            .single();

          if (slugProductData) {
            productData = slugProductData;
          } else if (productError) {
            // If not found by slug, try to find by matching the generated short slug
            const { data: allProducts, error: allProductsError } = await supabase
              .from('products')
              .select('*');

            if (!allProductsError && allProducts) {
              productData = allProducts.find(p => getProductSlug(p) === slug);
            }
          }
        }

        if (!productData) {
          console.error("Error fetching product:", productError?.message);
          toast({
            title: "المنتج غير موجود",
            description: "لم نتمكن من العثور على هذا المنتج. ربما تم حذفه.",
            variant: "destructive",
          });
          navigate('/products');
          return;
        }
        setProduct(productData);

        const images = [
          productData.main_image_url,
          productData.image_1,
          productData.image_2,
          productData.image_3,
          productData.image_4,
        ].filter(Boolean).slice(0, 5);
        
        setAllProductImages(images);
        setMainImage(images.length > 0 ? images[0] : 'https://via.placeholder.com/600x400?text=No+Image');
        
        const { data: relatedData, error: relatedError } = await supabase
          .from('products')
          .select('*')
          .neq('id', productData.id)
          .or(`category.eq.${productData.category},is_discounted.eq.true`)
          .limit(4);

        if (relatedError) {
          console.error("Error fetching related products:", relatedError);
        } else {
          setRelatedProducts(relatedData || []);
        }

      } catch (error) {
        console.error("Unexpected error:", error);
        toast({
          title: "خطأ غير متوقع",
          description: "حدث خطأ غير متوقع. يرجى المحاولة مرة أخرى.",
          variant: "destructive",
        });
      } finally {
        setLoading(false);
      }
    };

    fetchProductAndRelated();
    window.scrollTo(0, 0);
  }, [slug, supabase, navigate]);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-white text-xl">جاري التحميل...</div>
      </div>
    );
  }

  if (!product) {
    return (
       <div className="min-h-screen">
        <Header />
        <div className="container mx-auto px-4 py-8 text-center">
            <h1 className="text-3xl font-bold text-white mb-4">المنتج غير موجود</h1>
            <p className="text-white/70">عذراً، لم نتمكن من العثور على المنتج الذي تبحث عنه.</p>
            <Button onClick={() => navigate('/products')} className="mt-6">العودة للمنتجات</Button>
        </div>
        <Footer />
      </div>
    );
  }

  // تحديد ما إذا كان المنتج مخفض حقاً
  const isProductDiscounted = product.is_discounted === true || (product.discount_percent && product.discount_percent > 0);

  const discountedPrice = product.is_discounted && product.discount_percent
    ? getDiscountedPrice(product.price, product.discount_percent)
    : product.price;

  const handleAddToCart = () => {
    addToCart(product, quantity);
  };

  const handleBuyNow = () => {
    addToCart(product, quantity);
    navigate('/checkout');
  };

  const handleShare = async () => {
    const shareUrl = window.location.href;
    const shareTitle = product.name;
    const shareText = `اطلع على ${product.name}: ${product.description}`;

    try {
      if (navigator.share) {
        await navigator.share({
          title: shareTitle,
          text: shareText,
          url: shareUrl,
        });
        toast({
          title: "تمت المشاركة!",
          description: "تم مشاركة رابط المنتج بنجاح.",
        });
      } else {
        await navigator.clipboard.writeText(shareUrl);
        toast({
          title: "تم النسخ!",
          description: "تم نسخ رابط المنتج إلى الحافظة.",
        });
      }
    } catch (error) {
      console.error('Error sharing product:', error);
      toast({
        title: "خطأ في المشاركة",
        description: "لم نتمكن من مشاركة المنتج. حاول مرة أخرى.",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="min-h-screen">
      <Header />
      
      <div className="container mx-auto px-4 py-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex items-center gap-2 text-white/70 mb-8"
        >
          <button onClick={() => navigate('/products')} className="hover:text-purple-400 transition-colors">
            المنتجات
          </button>
          <ArrowLeft className="h-4 w-4" />
          <span className="text-white font-semibold">{product.name}</span>
        </motion.div>

        <div className="grid lg:grid-cols-2 gap-12 mb-16">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            className="space-y-4"
          >
            <div className="relative overflow-hidden rounded-2xl shadow-2xl bg-white flex justify-center items-center">
              <img
                src={mainImage}
                alt={product.name}
                className="max-w-full max-h-[500px] h-auto object-contain transition-all duration-300 ease-in-out p-4"
              />
              {product.is_discounted && product.discount_percent > 0 && (
                <div className="absolute top-4 left-4 bg-red-600 text-white px-3 py-1 rounded-full text-sm font-bold shadow-md">
                  -{product.discount_percent}%
                </div>
              )}
            </div>
            
            {allProductImages.length > 1 && (
              <div className="grid grid-cols-5 gap-3">
                {allProductImages.map((image, index) => (
                  <button
                    key={index}
                    onClick={() => setMainImage(image)}
                    className={`relative overflow-hidden rounded-lg border-2 transition-all duration-200 ease-in-out aspect-square
                      ${mainImage === image ? 'border-purple-500 scale-105 shadow-lg' : 'border-gray-700 hover:border-purple-400'
                    }`}
                  >
                    <img
                      src={image}
                      alt={`${product.name_en || product.name} thumbnail ${index + 1}`}
                      className="w-full h-full object-cover"
                    />
                  </button>
                ))}
              </div>
            )}
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            className="space-y-6 flex flex-col"
          >
            <div>
              <h1 className="text-3xl lg:text-4xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-pink-500 mb-3">{product.name}</h1>
              <div className="text-white/70 text-lg leading-relaxed" style={{ whiteSpace: 'pre-line' }}>{product.description}</div>
            </div>

            <div className="space-y-3 pt-2">
              <ProductPriceDisplay
                price={product.price}
                discountedPrice={isProductDiscounted && product.discounted_price ? product.discounted_price : 0}
                finalPriceClassName="text-4xl font-bold text-purple-400"
                originalPriceClassName="text-white/50 text-xl line-through ml-4"
                discountTextClassName="text-green-400 text-lg ml-4"
                className="flex flex-col items-start"
              />
            </div>

            <div className="flex items-center gap-4 text-sm">
              <span className="text-white/60">المخزون:</span>
              <span className={`font-bold px-2 py-0.5 rounded-md ${product.stock > 5 ? 'bg-green-500/20 text-green-400' : product.stock > 0 ? 'bg-orange-500/20 text-orange-400' : 'bg-red-500/20 text-red-400'}`}>
                {product.stock > 0 ? `${product.stock} قطعة متوفرة` : 'نفد المخزون'}
              </span>
            </div>

            <div className="flex items-center gap-4 text-sm">
              <span className="text-white/60">الرمز (Barcode):</span>
              <span className="text-white font-mono bg-gray-700/50 px-2 py-0.5 rounded">{product.barcode}</span>
            </div>

            {product.stock > 0 && (
              <div className="flex items-center gap-4 pt-2">
                <span className="text-white/60">الكمية:</span>
                <div className="flex items-center gap-2 bg-gray-800/60 rounded-lg">
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => setQuantity(Math.max(1, quantity - 1))}
                    className="text-white hover:bg-purple-500/30"
                    disabled={quantity <= 1}
                  >
                    <Minus className="h-4 w-4" />
                  </Button>
                  <span className="text-white font-bold w-10 text-center text-lg">{quantity}</span>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => setQuantity(Math.min(product.stock, quantity + 1))}
                    className="text-white hover:bg-purple-500/30"
                    disabled={quantity >= product.stock}
                  >
                    <Plus className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            )}

            <div className="flex flex-col sm:flex-row gap-4 pt-4">
              <Button
                onClick={handleAddToCart}
                className="flex-1 gradient-bg hover:opacity-90 text-white text-lg py-3 shadow-lg hover:shadow-purple-500/50 transition-shadow"
                disabled={product.stock === 0}
              >
                <ShoppingCart className="h-5 w-5 mr-2" />
                {product.stock === 0 ? 'نفد المخزون' : 'إضافة للسلة'}
              </Button>
              <Button
                onClick={handleBuyNow}
                variant="outline"
                className="flex-1 border-purple-500 text-purple-400 hover:bg-purple-500/10 hover:text-purple-300 text-lg py-3 shadow-lg hover:shadow-purple-500/30 transition-all"
                disabled={product.stock === 0}
              >
                اطلب الآن
              </Button>
            </div>

            <div className="flex justify-end pt-2">
              <Button 
                variant="ghost" 
                className="text-purple-400 hover:text-purple-300 hover:bg-purple-500/10"
                onClick={handleShare}
              >
                <Share2 className="h-5 w-5 mr-2" />
                مشاركة المنتج
              </Button>
            </div>
          </motion.div>
        </div>

        {relatedProducts.length > 0 && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
          >
            <h2 className="text-2xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-pink-500 mb-6">قد يعجبك أيضاً</h2>
            <div className="grid grid-cols-2 sm:grid-cols-2 md:grid-cols-4 gap-4">
              {relatedProducts.map((relatedProduct, index) => (
                <ProductCard key={relatedProduct.id} product={relatedProduct} index={index} />
              ))}
            </div>
          </motion.div>
        )}
      </div>

      <Footer />
    </div>
  );
};

export default ProductDetailPage;
