
import React, { useState, useEffect } from 'react';
import { useParams, useSearchParams, useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { Search, ChevronDown, Filter } from 'lucide-react';
import { Button } from '@/components/ui/button';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import ProductCard from '@/components/ProductCard';
import { categoriesData } from '@/data/products'; 
import { useSupabase } from '@/contexts/SupabaseContext';
import { toast } from "@/components/ui/use-toast";

const ProductsPage = () => {
  const { category } = useParams();
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const [allProducts, setAllProducts] = useState([]);
  const [filteredProducts, setFilteredProducts] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [sortBy, setSortBy] = useState('name');
  const [filterByAvailability, setFilterByAvailability] = useState('all');
  const [currentPage, setCurrentPage] = useState(1);
  const [loading, setLoading] = useState(true);
  const [isFilterMenuOpen, setIsFilterMenuOpen] = useState(false);
  const productsPerPage = 12;
  const { supabase } = useSupabase();
  const [aiSearching, setAiSearching] = useState(false);

  useEffect(() => {
    const fetchAllProducts = async () => {
      setLoading(true);
      try {
        let query = supabase.from('products').select('*').eq('published', true);
        const { data, error } = await query;

        if (error) throw error;
        setAllProducts(data || []);
      } catch (error) {
        console.error("Error fetching all products:", error);
        toast({
          title: "خطأ في تحميل المنتجات",
          description: "لم نتمكن من تحميل جميع المنتجات. يرجى المحاولة مرة أخرى.",
          variant: "destructive",
        });
      } finally {
        setLoading(false);
      }
    };
    if (supabase) {
      fetchAllProducts();
    }
  }, [supabase]);

  useEffect(() => {
    if (loading || aiSearching) return;

    let result = [...allProducts];
    const filterParam = searchParams.get('filter');
    
    if (filterParam === 'discounted') {
      result = result.filter(product => product.is_discounted);
    } else if (filterParam === 'featured') {
      result = result.filter(product => product.is_featured);
    } else if (category && category !== 'all') {
      result = result.filter(product => product.category === category);
    }

    if (searchTerm) {
      result = result.filter(product =>
        (product.name && product.name.toLowerCase().includes(searchTerm.toLowerCase())) ||
        (product.name_en && product.name_en.toLowerCase().includes(searchTerm.toLowerCase())) ||
        (product.description && product.description.toLowerCase().includes(searchTerm.toLowerCase())) ||
        (product.description_en && product.description_en.toLowerCase().includes(searchTerm.toLowerCase()))
      );
    }

    if (filterByAvailability === 'discounted') {
      result = result.filter(product => product.is_discounted);
    } else if (filterByAvailability === 'low-stock') {
      result = result.filter(product => product.stock <= 5 && product.stock > 0);
    } else if (filterByAvailability === 'out-of-stock') {
      result = result.filter(product => product.stock === 0);
    }

    result.sort((a, b) => {
      const priceA = a.is_discounted ? getDiscountedPrice(a.price, a.discount_percent) : a.price;
      const priceB = b.is_discounted ? getDiscountedPrice(b.price, b.discount_percent) : b.price;
      switch (sortBy) {
        case 'price-low':
          return priceA - priceB;
        case 'price-high':
          return priceB - priceA;
        case 'name':
        default:
          return (a.name || '').localeCompare(b.name || '', 'ar');
      }
    });

    setFilteredProducts(result);
    setCurrentPage(1);
  }, [category, searchParams, searchTerm, sortBy, filterByAvailability, allProducts, loading, aiSearching]);

  const totalPages = Math.ceil(filteredProducts.length / productsPerPage);
  const startIndex = (currentPage - 1) * productsPerPage;
  const currentProducts = filteredProducts.slice(startIndex, startIndex + productsPerPage);

  const currentCategoryInfo = categoriesData.find(cat => cat.id === category);
  const filterParam = searchParams.get('filter');
  
  let pageTitle = 'جميع المنتجات';
  if (filterParam === 'discounted') pageTitle = 'المنتجات المخفضة';
  else if (filterParam === 'featured') pageTitle = 'الكمية المحدودة';
  else if (currentCategoryInfo) pageTitle = currentCategoryInfo.name;

  const getDiscountedPrice = (price, discountPercent) => {
    if (!price || !discountPercent) return price;
    return price - (price * discountPercent / 100);
  };

  const handleCategoryClick = (catId) => {
    setAiSearching(false);
    setFilteredProducts(allProducts);
    navigate(catId === 'all' ? '/products' : `/products/${catId}`);
    setIsFilterMenuOpen(false);
  }

  return (
    <div className="min-h-screen">
      <Header />
      
      <div className="container mx-auto px-4 py-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <h1 className="text-3xl font-bold text-white mb-4">{pageTitle}</h1>
          {!loading && (
            <p className="text-white/60">
              عرض {filteredProducts.length} منتج
            </p>
          )}
          {(loading || aiSearching) && <p className="text-white/60">جاري تحميل المنتجات...</p>}
        </motion.div>

        <div className="mb-8 hidden md:flex flex-wrap gap-2">
          {categoriesData.map((cat) => (
            <Button
              key={cat.id}
              variant={category === cat.id || (!category && cat.id === 'all' && !filterParam) ? "default" : "outline"}
              className={`${
                (category === cat.id || (!category && cat.id === 'all' && !filterParam))
                  ? "gradient-bg text-white" 
                  : "border-white/20 text-white hover:bg-white/10"
              }`}
              onClick={() => handleCategoryClick(cat.id)}
            >
              {cat.name}
            </Button>
          ))}
        </div>

        <div className="grid lg:grid-cols-4 gap-4 mb-8">
          <div className="lg:col-span-2 relative">
            <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 text-white/40 h-5 w-5" />
            <input
              type="text"
              placeholder="البحث عن المنتجات..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-4 pr-12 py-3 rounded-lg bg-white/10 border border-white/20 text-white placeholder-white/60 focus:outline-none focus:ring-2 focus:ring-purple-500"
            />
          </div>

          <div className="relative">
            <select
              value={filterByAvailability}
              onChange={(e) => setFilterByAvailability(e.target.value)}
              className="w-full px-4 py-3 rounded-lg bg-input border border-border text-foreground focus:outline-none focus:ring-2 focus:ring-ring appearance-none"
            >
              <option value="all">كل حالات التوفر</option>
              <option value="discounted">المنتجات المخفضة</option>
              <option value="low-stock">مخزون قليل (1-5)</option>
              <option value="out-of-stock">نفد المخزون</option>
            </select>
            <ChevronDown className="absolute left-3 top-1/2 transform -translate-y-1/2 text-white/40 h-5 w-5 pointer-events-none" />
          </div>

          <div className="relative">
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value)}
              className="w-full px-4 py-3 rounded-lg bg-input border border-border text-foreground focus:outline-none focus:ring-2 focus:ring-ring appearance-none"
            >
              <option value="name">ترتيب حسب الاسم</option>
              <option value="price-low">السعر: من الأقل للأعلى</option>
              <option value="price-high">السعر: من الأعلى للأقل</option>
            </select>
            <ChevronDown className="absolute left-3 top-1/2 transform -translate-y-1/2 text-white/40 h-5 w-5 pointer-events-none" />
          </div>
        </div>

        <div className="md:hidden mb-4 relative">
          <Button onClick={() => setIsFilterMenuOpen(!isFilterMenuOpen)} className="w-full flex items-center justify-center gap-2">
            <Filter className="h-4 w-4" />
            <span>تصنيف حسب الفئة</span>
            <ChevronDown className={`h-4 w-4 transition-transform ${isFilterMenuOpen ? 'rotate-180' : ''}`} />
          </Button>
          <AnimatePresence>
            {isFilterMenuOpen && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                exit={{ opacity: 0, height: 0 }}
                className="absolute top-full left-0 right-0 bg-gray-800 rounded-lg mt-2 p-2 z-20 border border-white/20"
              >
                <div className="flex flex-col gap-1">
                  {categoriesData.map((cat) => (
                    <Button
                      key={cat.id}
                      variant="ghost"
                      className="w-full justify-start text-white hover:bg-white/10"
                      onClick={() => handleCategoryClick(cat.id)}
                    >
                      {cat.name}
                    </Button>
                  ))}
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
        
        {loading || aiSearching ? (
            <div className="text-center py-16 text-white/80">{aiSearching ? 'جاري البحث بذكاء...' : 'جاري تحميل المنتجات...'}</div>
        ) : filteredProducts.length === 0 ? (
          <div className="text-center py-16">
            <div className="text-white/60 text-lg">
              لم يتم العثور على منتجات مطابقة لبحثك أو الفلترة المختارة.
            </div>
          </div>
        ) : (
          <div className="grid grid-cols-2 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 mb-8">
            {currentProducts.map((product, index) => (
              <ProductCard key={product.id} product={product} index={index} />
            ))}
          </div>
        )}

        {!loading && !aiSearching && totalPages > 1 && (
          <div className="flex justify-center gap-2">
            {Array.from({ length: totalPages }, (_, i) => i + 1).map((page) => (
              <Button
                key={page}
                variant={currentPage === page ? "default" : "outline"}
                className={`${
                  currentPage === page 
                    ? "gradient-bg text-white" 
                    : "border-white/20 text-white hover:bg-white/10"
                }`}
                onClick={() => setCurrentPage(page)}
              >
                {page}
              </Button>
            ))}
          </div>
        )}

      </div>

      <Footer />
    </div>
  );
};

export default ProductsPage;
