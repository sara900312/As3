import React, { useState, useEffect, useCallback } from 'react';
import { Button } from '@/components/ui/button';
import { useNavigate } from 'react-router-dom';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import { toast } from '@/components/ui/use-toast';
import { useSupabase } from '@/contexts/SupabaseContext';
import { useAuth } from '@/contexts/AuthContext';
import { categoriesData } from '@/data/products';
import { generateBarcode } from '@/lib/utils';
import { Edit, Trash2, LogOut, Sparkles, Upload, TestTube } from 'lucide-react';
import { testGeminiEdgeFunction } from '@/lib/testEdgeFunction';

const InventoryPage = () => {
    const navigate = useNavigate();
    const { supabase } = useSupabase();
    const { userRole, signOut } = useAuth();

    const [products, setProducts] = useState([]);
    const [loadingProducts, setLoadingProducts] = useState(false);
    const [editingProduct, setEditingProduct] = useState(null);
    
    const getInitialFormData = () => ({
        name: '',
        description: '',
        price: '',
        discounted_price: '',
        stock: '',
        category: '',
        published: false,
        main_image_url: '',
        image_1: '',
        image_2: '',
        image_3: '',
        main_store_name: '',
    });

    const [formData, setFormData] = useState(getInitialFormData());
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [aiPrompt, setAiPrompt] = useState('');
    const [isGenerating, setIsGenerating] = useState(false);

    const canPublish = userRole === 'admin';
    const canUseFeature = userRole === 'admin' || userRole === 'assistant';

    const fetchProducts = useCallback(async () => {
        setLoadingProducts(true);
        const { data, error } = await supabase.from('products').select('*').order('created_at', { ascending: false });
        if (error) {
            toast({ title: "Error fetching products", description: error.message, variant: "destructive" });
        } else {
            setProducts(data);
        }
        setLoadingProducts(false);
    }, [supabase]);

    useEffect(() => {
        if (!canUseFeature) {
            toast({ title: "Access denied", description: "You don't have permission to view this page.", variant: "destructive" });
            navigate('/');
        } else {
            fetchProducts();
        }
    }, [fetchProducts, canUseFeature, navigate]);

    const handleInputChange = (e) => {
        const { name, value, type, checked } = e.target;
        setFormData(prev => ({ ...prev, [name]: type === 'checkbox' ? checked : value }));
    };

    const handleGenerateWithAI = async () => {
        if (!aiPrompt) {
            toast({ title: "Please enter a product description.", variant: "destructive" });
            return;
        }
        setIsGenerating(true);
        try {
            // استدعاء Edge Function بدلاً من Gemini مباشرة
            const { data: aiResponse, error: edgeError } = await supabase.functions.invoke('ai-add-product', {
                body: {
                    action: 'generateCompleteProduct',
                    description: aiPrompt
                }
            });

            if (edgeError) {
                throw new Error(edgeError.message || 'خطأ في خدمة الذكاء الاصطناعي');
            }

            if (!aiResponse.success) {
                throw new Error(aiResponse.error || 'فشل في توليد المنتج');
            }

            const aiData = aiResponse.data;

            // التحقق من صحة البيانات المولدة
            if (!aiData || !aiData.name || !aiData.price || !aiData.stock) {
                throw new Error("البيانات المولدة غير مكتملة");
            }

            // توليد الباركود
            const barcode = await generateBarcode(supabase);

            // إعداد بيانات المنتج
            const newProduct = {
                name: aiData.name,
                description: aiData.description || `منتج عالي الجودة - ${aiData.name}`,
                price: parseFloat(aiData.price) || 100,
                discounted_price: parseFloat(aiData.discounted_price) || 0,
                stock: parseInt(aiData.stock) || 1,
                barcode: barcode,
                category: aiData.category || 'uncategorized',
                published: false,
                slug: aiData.name.toLowerCase().replace(/ /g, '-').replace(/[^\w\u0600-\u06FF-]+/g, ''),
                main_image_url: aiData.image_url || '',
                specifications: aiData.specifications || ''
            };

            // حفظ المنتج في قاعدة البيانات
            const { error: insertError } = await supabase.from('products').insert([newProduct]);
            if (insertError) throw insertError;

            toast({
                title: "✅ تم إضافة المنتج بنجاح",
                description: `تم إنشاء المنتج "${aiData.name}" بواسطة الذكاء الاصطناعي`
            });
            setAiPrompt('');
            fetchProducts();
        } catch (error) {
            console.error('AI Product Generation Error:', error);
            toast({
                title: "خطأ ف�� توليد ال��نتج",
                description: error.message || 'حد�� خطأ غير متوقع',
                variant: "destructive"
            });
        } finally {
            setIsGenerating(false);
        }
    };

    const handleEdit = (product) => {
        setEditingProduct(product);
        setFormData({
            name: product.name || '',
            description: product.description || '',
            price: product.price || '',
            discounted_price: product.discounted_price || '',
            stock: product.stock || '',
            category: product.category || '',
            published: product.published || false,
            main_image_url: product.main_image_url || '',
            image_1: product.image_1 || '',
            image_2: product.image_2 || '',
            image_3: product.image_3 || '',
            main_store_name: product.main_store_name || '',
        });
    };

    const handleDelete = async (productId) => {
        if (!window.confirm('هل أنت متأكد أنك تريد حذف هذا المنتج؟')) return;
        const { error } = await supabase.from('products').delete().eq('id', productId);
        if (error) {
            toast({ title: "خطأ في الحذف", description: error.message, variant: "destructive" });
        } else {
            toast({ title: "تم ح��ف المنتج بنج��ح" });
            fetchProducts();
        }
    };

    const handleCancelEdit = () => {
        setEditingProduct(null);
        setFormData(getInitialFormData());
    };

    const handleSubmitManual = async (e) => {
        e.preventDefault();
        setIsSubmitting(true);
        
        try {
            const barcode = editingProduct ? editingProduct.barcode : await generateBarcode(supabase);
            
            const sanitizedData = {
                name: formData.name,
                description: formData.description,
                price: parseFloat(formData.price) || 0,
                discounted_price: parseFloat(formData.discounted_price) || 0,
                stock: parseInt(formData.stock, 10) || 0,
                category: formData.category || 'uncategorized',
                published: canPublish ? formData.published : false,
                barcode,
                slug: formData.name.toLowerCase().replace(/ /g, '-').replace(/[^\w-]+/g, ''),
                main_image_url: formData.main_image_url,
                image_1: formData.image_1,
                image_2: formData.image_2,
                image_3: formData.image_3,
                main_store_name: formData.main_store_name,
            };

            let error;
            if (editingProduct) {
                delete sanitizedData.barcode;
                ({ error } = await supabase.from('products').update(sanitizedData).eq('id', editingProduct.id));
            } else {
                ({ error } = await supabase.from('products').insert([sanitizedData]));
            }
            
            if (error) throw error;

            toast({ title: editingProduct ? "تم تحديث المنتج بنجاح!" : "تمت إضافة المنتج بنجاح!" });
            handleCancelEdit();
            fetchProducts();
        } catch (error) {
            toast({ title: "خطأ في العملية", description: error.message, variant: "destructive"});
        } finally {
            setIsSubmitting(false);
        }
    };
    
    const handleLogout = async () => {
        await signOut();
        toast({ title: "تم تسجيل الخروج بنجاح" });
        navigate('/');
    };

    // اختبار Edge Function
    const handleTestEdgeFunction = async () => {
        try {
            toast({ title: "جاري اختبار Edge Function..." });
            const result = await testGeminiEdgeFunction();

            if (result.success) {
                toast({
                    title: "✅ Edge Function يعمل بنجاح",
                    description: "تم اختبار الاتصال بنجاح"
                });
                console.log('نتيجة الاختبار:', result.data);
            } else {
                toast({
                    title: "❌ فشل في اختبار Edge Function",
                    description: result.error,
                    variant: "destructive"
                });
            }
        } catch (error) {
            toast({
                title: "خطأ في الاختبار",
                description: error.message,
                variant: "destructive"
            });
        }
    };

    const FileInput = ({ name, value, onChange, placeholder }) => (
        <div className="relative">
            <input name={name} value={value || ''} onChange={onChange} placeholder={placeholder} className="w-full bg-gray-800 text-white p-2 rounded pl-10" />
            <Upload className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400"/>
        </div>
    );

    return (
        <div className="min-h-screen flex flex-col bg-gray-900 text-white">
            <Header />
            <main className="flex-grow container mx-auto px-4 py-8">
                <div className="flex justify-between items-center mb-8">
                    <h1 className="text-3xl font-bold">ل��حة تحكم المخزن</h1>
                    <div className="flex gap-4">
                        <Button onClick={() => navigate('/')} variant="outline">العودة للمتجر</Button>
                        <Button onClick={handleTestEdgeFunction} variant="secondary">
                            <TestTube className="w-4 h-4 mr-2" />
                            اختبار AI
                        </Button>
                        <Button onClick={handleLogout} variant="destructive"><LogOut className="w-4 h-4 mr-2" />تسجيل الخروج</Button>
                    </div>
                </div>
                
                <div className="grid md:grid-cols-3 gap-8 mt-6">
                    <div className="md:col-span-1 space-y-6">
                        {canUseFeature && (
                            <div className="glass-effect rounded-xl p-6">
                                <h2 className="text-xl font-bold mb-4 flex items-center"><Sparkles className="w-5 h-5 mr-2 text-yellow-400" />إضافة سريعة بالذكاء الاصطناعي</h2>
                                <div className="space-y-4">
                                    <label htmlFor="ai-prompt" className="text-sm font-medium">اسم المنتج أو وصف مختصر</label>
                                    <textarea id="ai-prompt" value={aiPrompt} onChange={(e) => setAiPrompt(e.target.value)} placeholder="مثال: سماعات بلوتوث مع خاصية عزل الضوضاء" className="w-full bg-gray-800 p-2 rounded" rows="3"/>
                                    <Button onClick={handleGenerateWithAI} disabled={isGenerating} className="w-full">{isGenerating ? 'جاري الإنشاء...' : 'إنشاء وحفظ المنتج'}</Button>
                                </div>
                            </div>
                        )}

                        <div className="glass-effect rounded-xl p-6">
                            <h2 className="text-xl font-bold mb-4">{editingProduct ? 'تعديل المنتج' : 'إضافة منتج يدوي'}</h2>
                            <form onSubmit={handleSubmitManual} className="space-y-4">
                                <input name="name" value={formData.name} onChange={handleInputChange} placeholder="اسم المنتج" className="w-full bg-gray-800 p-2 rounded" required />
                                <input name="main_store_name" value={formData.main_store_name} onChange={handleInputChange} placeholder="اسم المتجر الرئ��سي" className="w-full bg-gray-800 p-2 rounded" />
                                <textarea name="description" value={formData.description} onChange={handleInputChange} placeholder="الوصف" className="w-full bg-gray-800 p-2 rounded" rows="3"/>
                                <input name="price" type="number" value={formData.price} onChange={handleInputChange} placeholder="السعر الأصلي" className="w-full bg-gray-800 p-2 rounded" required />
                                <input name="discounted_price" type="number" value={formData.discounted_price} onChange={handleInputChange} placeholder="مقدار الخصم (اختياري)" className="w-full bg-gray-800 p-2 rounded" />
                                <input name="stock" type="number" value={formData.stock} onChange={handleInputChange} placeholder="الكمية" className="w-full bg-gray-800 p-2 rounded" required />
                                <select name="category" value={formData.category} onChange={handleInputChange} className="w-full bg-gray-800 p-2 rounded">
                                    <option value="">اختر الفئة</option>
                                    {categoriesData.filter(c => c.id !== 'all').map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                                </select>
                                
                                <FileInput name="main_image_url" value={formData.main_image_url} onChange={handleInputChange} placeholder="رابط الصورة الرئيسية" />
                                <FileInput name="image_1" value={formData.image_1} onChange={handleInputChange} placeholder="رابط صورة فرعية 1" />
                                <FileInput name="image_2" value={formData.image_2} onChange={handleInputChange} placeholder="رابط صورة فرعية 2" />
                                <FileInput name="image_3" value={formData.image_3} onChange={handleInputChange} placeholder="رابط صورة فرعية 3" />
                                
                                {canPublish && (
                                    <div className="flex items-center space-x-2 dir-rtl">
                                        <input type="checkbox" id="published" name="published" checked={formData.published} onChange={handleInputChange} className="h-4 w-4 rounded border-gray-300 text-indigo-600 focus:ring-indigo-500" />
                                        <label htmlFor="published" className="text-sm font-medium">نشر المنتج؟</label>
                                    </div>
                                )}
                                <div className="flex gap-2">
                                    {editingProduct && <Button type="button" variant="secondary" onClick={handleCancelEdit} className="w-full">��لغاء</Button>}
                                    <Button type="submit" disabled={isSubmitting} className="w-full">{isSubmitting ? 'جاري الحفظ...' : (editingProduct ? 'حفظ التعديلات' : 'إضافة المنتج')}</Button>
                                </div>
                            </form>
                        </div>
                    </div>

                    <div className="md:col-span-2 glass-effect rounded-xl p-6">
                        <h2 className="text-xl font-bold mb-4">قائمة المنتجات</h2>
                        <div className="max-h-[80vh] overflow-y-auto pr-2">
                            {loadingProducts ? <p>جاري تحميل المنتجات...</p> : (
                                <div className="space-y-4">
                                    {products.map(p => {
                                        const canModify = userRole === 'admin' || !p.published;
                                        return (
                                            <div key={p.id} className="bg-gray-800/50 p-3 rounded-lg flex justify-between items-center">
                                                <div>
                                                    <p className="font-bold">{p.name}</p>
                                                    <p className="text-sm text-white/60">الكمية: {p.stock} | الباركود: {p.barcode}</p>
                                                    <p className={`text-xs font-semibold ${p.published ? 'text-green-400' : 'text-yellow-400'}`}>{p.published ? 'منشور' : 'غير منشور'}</p>
                                                </div>
                                                <div className="flex gap-2">
                                                    <Button size="sm" variant="outline" onClick={() => handleEdit(p)} disabled={!canModify}><Edit className="w-4 h-4" /></Button>
                                                    <Button size="sm" variant="destructive" onClick={() => handleDelete(p.id)} disabled={!canModify}><Trash2 className="w-4 h-4" /></Button>
                                                </div>
                                            </div>
                                        );
                                    })}
                                </div>
                            )}
                        </div>
                    </div>
                </div>
            </main>
            <Footer />
        </div>
    );
};

export default InventoryPage;
