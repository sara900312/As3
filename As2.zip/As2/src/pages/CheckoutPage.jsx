import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ArrowLeft, Package, User, CreditCard, Copy, X as CloseIcon } from 'lucide-react';
import { Button } from '@/components/ui/button';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import { useCart } from '@/contexts/CartContext';
import { useNavigate } from 'react-router-dom';
import { toast } from '@/components/ui/use-toast';
import CheckoutForm from '@/components/checkout/CheckoutForm';
import OrderSummary from '@/components/checkout/OrderSummary';
import ConfirmationModal from '@/components/checkout/ConfirmationModal';
import OrderConfirmedDisplay from '@/components/checkout/OrderConfirmedDisplay';
import { formatPrice } from '@/data/products';
import { useSupabase } from '@/contexts/SupabaseContext';
import { sendOrder } from '@/lib/orderService';
import { createPersistentIdempotencyKey, sendOrderNotification } from '@/lib/orderNotification';


const CheckoutPage = () => {
  const { cartItems, getTotalPrice, clearCart } = useCart();
  const { supabase } = useSupabase();
  const navigate = useNavigate();
  
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showConfirmation, setShowConfirmation] = useState(false);
  const [orderConfirmed, setOrderConfirmed] = useState(false);
  const [orderCode, setOrderCode] = useState('');
  const [showOrderCodeSection, setShowOrderCodeSection] = useState(false);
  const [countdown, setCountdown] = useState(10);
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    address: '', 
    notes: ''
  });

    const getCityFromAddress = (address) => {
    if (address.toLowerCase().includes('بغداد') || address.toLowerCase().includes('baghdad')) {
      return 'baghdad';
    }
    return 'other';
  };

  // Ref to track if order is being processed to prevent duplicates
  const isProcessingOrder = useRef(false);
  const hasSubmitted = useRef(false);

  // إنشاء مرجع لمفتاح التكرار
  const idempotencyKeyRef = useRef(null);

  const deliveryCosts = {
    baghdad: 5000,
    other: 10000
  };
  
  const inferredCity = formData.address ? getCityFromAddress(formData.address) : 'other';
  const deliveryCost = deliveryCosts[inferredCity];
  const subtotal = getTotalPrice();
  const totalWithDelivery = subtotal + deliveryCost;

  // حساب إجمالي مبلغ الخصم للطلب
  const getTotalDiscountAmount = () => {
    return cartItems.reduce((totalDiscount, item) => {
      const isProductDiscounted = item.is_discounted === true || (item.discount_percent && item.discount_percent > 0);
      // حساب مقدار الخصم = السعر الأصلي - السعر النهائي
      const finalPrice = isProductDiscounted && item.discounted_price ? item.discounted_price : item.price;
      const discountPerItem = isProductDiscounted ? Math.max(0, item.price - finalPrice) : 0;
      return totalDiscount + (discountPerItem * item.quantity);
    }, 0);
  };

  const totalDiscountAmount = getTotalDiscountAmount();

  const generateUniqueOrderCode = () => {
    const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    let result = '';
    for (let i = 0; i < 7; i++) {
      result += characters.charAt(Math.floor(Math.random() * characters.length));
    }
    return result;
  };

  // إنشاء مفتاح التكرار عند بدء العملية
  const generateIdempotencyKey = () => {
    if (!idempotencyKeyRef.current) {
      idempotencyKeyRef.current = crypto.randomUUID();
    }
    return idempotencyKeyRef.current;
  };

  // دالة محسّنة لإرسال الطلب بالتنسيق الصحيح
  const handleSubmitOrder = () => {
    const firstCartItem = cartItems.length > 0 ? cartItems[0] : {};
    const rawStoreData = firstCartItem.main_store_name || firstCartItem.main_store;
    const mainStoreValue = extractStoreName(rawStoreData);
    const currentOrderCode = generateUniqueOrderCode();

    const orderData = {
      customer_name: formData.name,
      customer_phone: formData.phone,
      customer_address: formData.address,
      customer_city: inferredCity === 'baghdad' ? 'بغداد' : 'محافظات أخرى',
      customer_notes: formData.notes || 'رجاءً توصيل سريع',
      subtotal: subtotal,
      delivery_cost: deliveryCost,
      discounted_price: totalDiscountAmount,
      total_amount: totalWithDelivery,
      order_code: currentOrderCode,
      main_store_name: mainStoreValue,
      user_id: null, // uuid-المستخدم-هنا
      idempotency_key: generateIdempotencyKey(), // استخدام المفتاح الموحد

      // **مهم**: عناصر الطلب، كل عنصر يحتوي على:
      items: cartItems.map(item => ({
        product_id: item.id,
        quantity: item.quantity,
        price: item.price,
        discounted_price: item.discounted_price || null,
        product_name: item.name,
        main_store_name: extractStoreName(item.main_store_name || item.main_store) || mainStoreValue,
      }))
    };

    sendOrder(orderData)
      .then(result => {
        const storeName = result?.storeName ?? "غير محدد";
        console.log("تم إرسال الطلب. اسم المتجر:", storeName);

        // ✅ التأكد من أن toast لا يتم استدعاؤه د���خل render مباشرة
        setTimeout(() => {
          toast({
            title: "تم إرسال الطلب بنجاح!",
            description: `تم إرسال الطلب بنجاح إلى ${storeName}\nرقم طلبك هو: ${currentOrderCode}`,
          });
        }, 0);

        clearCart();
        setOrderCode(currentOrderCode);
        setOrderConfirmed(true);
        setShowOrderCodeSection(true);
      })
      .catch(err => {
        console.error("خطأ أثناء إرسال الطلب:", err);

        // ⚠️ التحقق من تكرار المفتاح
        const isDuplicate = err.message?.includes('duplicate key') ||
                           err.message?.includes('idempotency') ||
                           err.message?.includes('already exists') || false;

        setTimeout(() => {
          if (!isDuplicate) {
            toast({
              title: "خطأ في إرسال الطلب",
              description: err.message || "حدث خطأ غير متوقع أثناء إرسال الطلب. يرجى المحاولة مرة أخرى.",
              variant: "destructive",
            });
          }
          // No message for duplicate orders
        }, 0);
      });
  };

  const handleInputChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

    const handleFormSubmit = async () => {
    // Prevent duplicate submissions
    if (isSubmitting || isProcessingOrder.current) {
      return;
    }

    // Validation is now handled in CheckoutForm component

    setIsSubmitting(true);
    const newOrderCode = generateUniqueOrderCode();
    setOrderCode(newOrderCode);

    // ✨ أضف السطر التالي لإعادة توليد مفتاح جديد في كل طلب جديد فقط
    idempotencyKeyRef.current = crypto.randomUUID();

    setShowConfirmation(true);
    setOrderConfirmed(false); 

    if (window.countdownIntervalId) {
      clearInterval(window.countdownIntervalId);
    }

        // Start countdown with proper cleanup
    let countdownValue = 10;
    setCountdown(countdownValue);

    window.countdownIntervalId = setInterval(() => {
      countdownValue--;
      setCountdown(countdownValue);

      if (countdownValue <= 0) {
        clearInterval(window.countdownIntervalId);
        processOrderSubmission(newOrderCode);
      }
    }, 1000);
    };

  // إرسال ��لإشعار عبر Edge Function المرتبطة بقاعدة البيانات
  const sendOrderNotification = async (orderCode, mainStoreValue) => {
    try {
      if (hasSubmitted.current) return;
      hasSubmitted.current = true;

      console.log('📧 إرسال إشعار طلب عبر Edge Function');

      const orderData = {
        customer_name: formData.name,
        customer_phone: formData.phone,
        customer_address: formData.address,
        customer_city: inferredCity === 'baghdad' ? 'بغداد' : 'محافظات أخرى',
        customer_notes: formData.notes || '',
        items: cartItems.map(item => ({
          product_id: item.id,
          quantity: item.quantity,
          price: item.price,
          discounted_price: item.discounted_price || null,
          product_name: item.name,
          main_store_name: extractStoreName(item.main_store_name || item.main_store) || mainStoreValue
        })),
        subtotal: subtotal,
        delivery_cost: deliveryCost,
        discounted_price: totalDiscountAmount,
        total_amount: totalWithDelivery,
        order_code: orderCode,
        main_store_name: mainStoreValue,
        user_id: null,
        idempotency_key: generateIdempotencyKey(), // استخدام المفتاح الموحد
      };

      // إرسال الإشعار عبر Edge Function باستخدام الخدمة الجديدة
      const result = await sendOrder(orderData);
      return { success: true, data: result };
    } catch (error) {
      // طباعة تفاصيل الخطأ الكاملة للتشخيص
      console.error('❌ Network or Server Error:', error);

      // استخراج رسالة الخطأ المناسبة من كائن EmailJS
      return {
        success: false,
        error: error.message || 'Unknown error'
      };
    }
  };

      // دالة لاستخراج اسم المتجر من كائن أو نص
  const extractStoreName = (storeData) => {
    // إذا كان null أو undefined
    if (!storeData) return null;

    // إذا كان نص مباشر
    if (typeof storeData === 'string') {
      return storeData.trim() || null;
    }

    // إذا كان كائن، نحاول استخراج الاسم من خصائص مختلفة
    // نعطي أولوية لـ main_store_name
    if (typeof storeData === 'object') {
      return storeData.main_store_name ||
             storeData.name ||
             storeData.storeName ||
             storeData.title ||
             null; // لا نستخدم JSON.stringify كحل أخير
    }

    // في أي حالة أخرى، نحو��ه إلى نص
    return String(storeData).trim() || null;
  };

    // دالة مساعدة لطباعة معلومات تشخيص واضحة
  const getStoreDebugInfo = (storeData) => {
    return {
      raw: storeData,
      rawJson: JSON.stringify(storeData),
      type: typeof storeData,
      extracted: extractStoreName(storeData),
      isValid: isValidStoreName(storeData),
      constructor: storeData?.constructor?.name || 'Unknown'
    };
  };

  // دالة للتحقق من صحة اسم المتجر
  const isValidStoreName = (storeData) => {
    const storeName = extractStoreName(storeData);

    if (!storeName || typeof storeName !== 'string') {
      return false;
    }

    const invalidStoreNames = [
      'المتجر الرئيسي غير محدد',
      'المتجر الرئيسي',
      'غير محدد',
      'لا يوجد',
      'غير معروف',
      'متجر افتراضي',
      'null',
      'undefined',
      '{}',
      '[object Object]'
    ];

    const trimmedName = storeName.trim();
    return trimmedName.length > 0 && !invalidStoreNames.includes(trimmedName);
  };

    const processOrderSubmission = async (currentOrderCode) => {
    // Prevent multiple submissions using ref
    if (isProcessingOrder.current || orderConfirmed) {
      return;
    }

    // Set processing flag
    isProcessingOrder.current = true;
    // Reset notification submission flag for new order
    hasSubmitted.current = false; 

            try {
            // تحقق مبكر من صحة بيانات المتاجر
      const firstCartItem = cartItems.length > 0 ? cartItems[0] : {};
      // نعطي أولوية لـ main_store_name، ثم main_store كبديل
      const rawStoreData = firstCartItem.main_store_name || firstCartItem.main_store;
      const mainStoreValue = extractStoreName(rawStoreData);

      // طباعة معلومات مفيدة للتشخيص
                  console.log('🔍 تشخيص بيانات المتجر:', {
        main_store_name: firstCartItem.main_store_name,
        main_store: JSON.stringify(firstCartItem.main_store),
        selectedStoreData: getStoreDebugInfo(rawStoreData),
        extractedValue: mainStoreValue
      });

      if (!isValidStoreName(rawStoreData)) {
                        console.error('❌ فشل التحقق المبكر: اسم المتجر غير صحيح:', {
          storeDebugInfo: getStoreDebugInfo(rawStoreData),
          cartItemsStores: cartItems.map(item => ({
            name: item.name,
            main_store_name: item.main_store_name,
            main_store: JSON.stringify(item.main_store),
            storeDebugInfo: getStoreDebugInfo(item.main_store_name || item.main_store)
          }))
        });

        // استخدام useCallback أو setTimeout لتجنب setState أثناء الريندر
        setTimeout(() => {
          toast({
            title: "خطأ في بيانات المتجر",
            description: "لا يمكن إتمام الطلب بسبب معلومات متجر غير صحيحة. يرجى إضافة المنتجات من متجر محدد.",
            variant: "destructive",
            duration: 8000,
          });

          setIsSubmitting(false);
          setShowConfirmation(false);
        }, 0);

        return;
      }

      const orderDataForEmail = {
        name: formData.name,
        phone: formData.phone,
        email: 'لا يوجد', 
        detailed_address: formData.address,
        city: inferredCity === 'baghdad' ? 'بغداد' : 'محافظات أخرى', 
        notes: formData.notes || 'لا توجد ملاحظات',
        product_name: cartItems.map(item => `${item.name} (x${item.quantity})`).join(', '),
        product_price: formatPrice(subtotal),
        order_date: new Date().toLocaleDateString('ar-IQ'),
        order_code: currentOrderCode,
        all_items_details: cartItems.map(item => 
          `المنتج: ${item.name}\nالكمية: ${item.quantity}\nالسعر للقطعة: ${formatPrice(item.price)}\nالإجمالي للمنتج: ${formatPrice(item.price * item.quantity)}`
        ).join('\n\n'),
        subtotal_amount: formatPrice(subtotal),
        delivery_fee: formatPrice(deliveryCost),
        discounted_price: totalDiscountAmount,
        total_order_amount: formatPrice(totalWithDelivery),
        main_store: mainStoreValue,
      };
      

      
      // إرسال الإشعار مع idempotency key
      const idempotencyKey = generateIdempotencyKey(); // استخدام نفس المفتاح

      // Format product names and calculate total quantity
      const productNames = cartItems.map(item =>
        `${item.name} (x${item.quantity})`
      ).join(', ');
      const totalQuantity = cartItems.reduce((sum, item) => sum + item.quantity, 0);

      const notificationResult = await sendOrderNotification(
        currentOrderCode,
        productNames,
        totalQuantity,
        mainStoreValue,
        idempotencyKey
      );

            // نخزن نتيجة الإشعار لاستخدامها في رسالة النجاح النهائية
      const notificationSuccess = notificationResult.success;
      const notificationError = notificationResult.error;

      if (!notificationSuccess) {
        console.warn('⚠️ تحذير: فشل في إرسال إشعار الطلب:', notificationError);
      } else {
        const store = mainStoreValue || 'غير معروف';
        console.log('✅ تم إرسال إشعار الطلب بنجاح إلى متجر:', store);
      }

      // ✅ تحق�� من الطلب الم��رر قبل الإرسال
      const { data: existingOrder, error: fetchError } = await supabase
        .from('orders')
        .select('order_code')
        .eq('idempotency_key', idempotencyKey)
        .single();

      if (existingOrder) {
        // الطلب موجود مسبقًا - لا ترسل مرة ثانية
        console.warn('⛔ تم إرسال هذا الطلب مسبقًا:', existingOrder.order_code);

        // Order already exists - no message needed

        setOrderCode(existingOrder.order_code);
        setOrderConfirmed(true);
        setShowOrderCodeSection(true);
        setShowConfirmation(false);
        clearCart();
        return;
      }

      const orderDataForSupabase = {
        order_code: currentOrderCode,
        customer_name: formData.name,
        customer_phone: formData.phone,
        customer_address: formData.address, 
        customer_city: inferredCity, 
        customer_notes: formData.notes,
        items: cartItems.map(item => ({
          product_id: item.id,
          name: item.name,
          name_en: item.nameEn,
          quantity: item.quantity,
          price: item.price,
          discounted_price: item.discounted_price || null,
                    main_store: item.main_store_name || extractStoreName(item.main_store) || '��ير محدد'
        })),
        subtotal: subtotal,
        delivery_cost: deliveryCost,
        discounted_price: totalDiscountAmount,
        total_amount: totalWithDelivery,
        order_status: 'pending',
        idempotency_key: idempotencyKey, // استخدام نفس المفتاح
      };

      const { error: supabaseError } = await supabase
        .from('orders')
        .insert([orderDataForSupabase]);

      if (supabaseError) {
        if (supabaseError.code === '23505' && supabaseError.message.includes('orders_order_code_key')) {
          console.error('Duplicate order code error (Supabase):', supabaseError.message);
        } else {
          throw new Error(`Supabase error: ${supabaseError.message}`);
        }
      } else {
                // رسالة نجاح واحدة تجمع معلومات الطلب والإشعار
        const store = mainStoreValue || 'غير معروف';
        const successMessage = notificationSuccess
          ? `رقم طلبك هو: ${currentOrderCode}. تم إرسال الإشعار لمتجر "${store}" وسيتم ال��واصل م��ك قريباً.`
          : `رقم طلبك هو: ${currentOrderCode}. تم حفظ الطلب بنجاح ولكن فشل في إرسال الإشعار للمتجر. يرجى التواصل مع المتجر مباشرة.`;

        // ✅ تأجيل toast لتجنب مشاكل التنفيذ أثناء render
        setTimeout(() => {
          toast({
            title: "تم إرسال الطلب بنجاح!",
            description: successMessage,
            variant: notificationSuccess ? "default" : "default",
            duration: notificationSuccess ? 7000 : 10000,
          });
        }, 0);
        
        setOrderConfirmed(true);
        setShowOrderCodeSection(true);
        setShowConfirmation(false);
        clearCart();

        // 🔧 إعادة تعيين مفتاح التكرار بعد نجاح الطلب لضمان طلبات جديدة
        idempotencyKeyRef.current = null;
      }
        } catch (error) {
      console.error('Error sending order (generic):', JSON.stringify(error, null, 2));
      if (!(error.message.includes('Supabase error:') && error.message.includes('orders_order_code_key'))) {
        // ⚠️ التحقق من تكرار المفتاح في أخطاء قاعدة البيانات
        const isDuplicate = error.message?.includes('duplicate key') ||
                           error.message?.includes('idempotency') ||
                           error.message?.includes('orders_order_code_key') || false;

        setTimeout(() => {
          if (!isDuplicate) {
            toast({
              title: "خطأ في إرسال الطلب",
              description: `حدث خطأ: ${error.message}. يرجى المحاولة مرة أخرى أو التواصل معنا مباشرة.`,
              variant: "destructive",
              duration: 9000,
            });
          }
          // No message for duplicate orders
        }, 0);
      }
      setOrderConfirmed(false); 
      setShowConfirmation(false);
    } finally {
            setIsSubmitting(false);
      setCountdown(10);
      // Reset processing flag
      isProcessingOrder.current = false; 
    }
  };

      const cancelOrder = () => {
    if (window.countdownIntervalId) {
      clearInterval(window.countdownIntervalId);
    }
    setShowConfirmation(false);
    setIsSubmitting(false);
    setCountdown(10);
    setOrderCode('');
    // Reset processing flag
    isProcessingOrder.current = false;
    // إعادة تعيين مفتاح التكرار عند الإلغاء
    idempotencyKeyRef.current = null;
  };

  const confirmOrderImmediately = () => {
    if (window.countdownIntervalId) {
      clearInterval(window.countdownIntervalId);
    }
    processOrderSubmission(orderCode);
  };

  const handleCopyOrderCode = () => {
    if (orderCode) {
      navigator.clipboard.writeText(orderCode);
      toast({
        title: "تم نسخ رقم الطلب!",
        description: orderCode,
      });
    }
  };

  useEffect(() => {
    return () => {
      if (window.countdownIntervalId) {
        clearInterval(window.countdownIntervalId);
      }
    };
  }, []);

  if (cartItems.length === 0 && !orderConfirmed) {
    return (
      <div className="min-h-screen">
        <Header />
        <div className="container mx-auto px-4 py-16 text-center">
          <Package className="h-16 w-16 mx-auto text-themed-foreground/40 mb-4" />
          <h1 className="text-2xl font-bold text-themed-foreground mb-4">السلة فارغة</h1>
          <p className="text-themed-foreground/60 mb-8">لا توجد منتجات في سلة التسوق</p>
          <Button onClick={() => navigate('/products')} className="gradient-bg text-white">
            تصفح المنتجات
          </Button>
        </div>
        <Footer />
      </div>
    );
  }
  
  return (
    <div className="min-h-screen">
      <Header />
      
      <div className="container mx-auto px-4 py-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex items-center gap-2 text-themed-foreground/60 mb-8"
        >
          <button onClick={() => navigate(-1)} className="hover:text-themed-foreground">
            <ArrowLeft className="h-5 w-5" />
          </button>
          <h1 className="text-3xl font-bold text-themed-foreground">إتمام الطلب</h1>
        </motion.div>

        <div className="grid lg:grid-cols-2 gap-12">
          <CheckoutForm
            formData={formData}
            handleInputChange={handleInputChange}
            onAutoSubmit={handleFormSubmit}
            isSubmitting={isSubmitting}
          />
          <OrderSummary
            items={cartItems || []}
            subtotal={subtotal}
          />
        </div>
      </div>

            <ConfirmationModal
        isOpen={showConfirmation && !orderConfirmed}
        countdown={countdown}
        orderCode={orderCode}
        onCancel={cancelOrder}
        onConfirmImmediately={confirmOrderImmediately}
      />
      
      <OrderConfirmedDisplay
        isOpen={orderConfirmed && showOrderCodeSection}
        orderCode={orderCode}
        onCopy={handleCopyOrderCode}
        onClose={() => setShowOrderCodeSection(false)}
      />

      <Footer />
    </div>
  );
};

export default CheckoutPage;
