export const categoriesData = [
  { id: 'all', name: 'جميع المنتجات', nameEn: 'All Products' },
  { id: 'cpu', name: 'معالجات', nameEn: 'CPUs' },
  { id: 'gpu', name: 'كروت رسوميات', nameEn: 'Graphics Cards' },
  { id: 'ram', name: 'ذاكرة', nameEn: 'RAM' },
  { id: 'storage', name: 'تخزين', nameEn: 'Hard Drives' },
  { id: 'motherboard', name: 'لوحات أم', nameEn: 'Motherboards' },
  { id: 'monitor', name: 'شاشات', nameEn: 'Monitors' },
  { id: 'psu', name: 'مزودات طاقة', nameEn: 'Power Supplies' },
  { id: 'laptops', name: 'لابتوبات', nameEn: 'Laptops' },
  { id: 'accessories', name: 'إكسسوارات', nameEn: 'Accessories' },
  { id: 'mobiles', name: 'الموبايلات', nameEn: 'Mobile Phones' }
];

export const formatPrice = (price) => {
  if (price === null || price === undefined) return '';
  const formatted = new Intl.NumberFormat('ar-IQ', {
    style: 'currency',
    currency: 'IQD',
    minimumFractionDigits: 0
  }).format(price);

  // Replace regular spaces with non-breaking spaces, fix currency format
  return formatted
    .replace(/\s/g, '\u00A0')  // Replace spaces with non-breaking spaces
    .replace(/\.+/g, '')       // Remove all dots first
    .replace(/\u200F/g, '')    // Remove Right-to-Left marks if any
    .replace(/دع/g, 'د.ع');    // Add dot between د and ع
};

export const getDiscountedPrice = (price, discountPercent) => {
  if (price === null || price === undefined || discountPercent === null || discountPercent === undefined) return price;
  return price - (price * discountPercent / 100);
};
