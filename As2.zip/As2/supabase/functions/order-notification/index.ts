import { serve } from "https://deno.land/std@0.168.0/http/server.ts"
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
}

interface OrderRequest {
  customerName: string
  productName: string
  quantity: number
  storeName: string
}

interface StoreRecord {
  owner_email: string
  name: string
}

// إرسال البريد الإلكتروني عبر EmailJS API
async function sendEmailViaEmailJS(
  toEmail: string, 
  customerName: string, 
  productName: string, 
  quantity: number, 
  storeName: string
) {
  const serviceId = Deno.env.get('EMAILJS_SERVICE_ID')
  const templateId = Deno.env.get('EMAILJS_TEMPLATE_ID')
  const userId = Deno.env.get('EMAILJS_USER_ID')
  const accessToken = Deno.env.get('EMAILJS_ACCESS_TOKEN')
  
  if (!serviceId || !templateId || !userId || !accessToken) {
    throw new Error('EmailJS credentials not configured')
  }

  const templateParams = {
    to_email: toEmail,
    customer_name: customerName,
    product_name: productName,
    quantity: quantity,
    store_name: storeName,
    order_date: new Date().toLocaleDateString('ar-IQ', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    }),
    order_time: new Date().toLocaleTimeString('ar-IQ')
  }

  const emailData = {
    service_id: serviceId,
    template_id: templateId,
    user_id: userId,
    accessToken: accessToken,
    template_params: templateParams
  }

  console.log('📧 Sending email via EmailJS:', {
    toEmail,
    customerName,
    productName,
    quantity,
    storeName
  })

  const response = await fetch('https://api.emailjs.com/api/v1.0/email/send', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(emailData)
  })

  if (!response.ok) {
    const errorText = await response.text()
    throw new Error(`EmailJS API error: ${response.status} ${response.statusText} - ${errorText}`)
  }

  const result = await response.text()
  return { success: true, message: 'Email sent successfully', result }
}

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  try {
    if (req.method !== 'POST') {
      return new Response(
        JSON.stringify({ error: 'Method not allowed' }),
        { 
          status: 405, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        }
      )
    }

    // Parse request body only once
    const requestBody = await req.json()
    const { customerName, productName, quantity, storeName }: OrderRequest = requestBody

    // Validate required fields
    if (!customerName || !productName || !quantity || !storeName) {
      return new Response(
        JSON.stringify({ 
          error: 'Missing required fields: customerName, productName, quantity, storeName' 
        }),
        { 
          status: 400, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        }
      )
    }

    // Validate data types
    if (typeof customerName !== 'string' || typeof productName !== 'string' || 
        typeof quantity !== 'number' || typeof storeName !== 'string') {
      return new Response(
        JSON.stringify({ 
          error: 'Invalid data types: customerName and productName and storeName must be strings, quantity must be number' 
        }),
        { 
          status: 400, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        }
      )
    }

    // Initialize Supabase client with service role key for admin access
    const supabaseUrl = Deno.env.get('SUPABASE_URL')
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')
    
    if (!supabaseUrl || !supabaseServiceKey) {
      return new Response(
        JSON.stringify({ error: 'Supabase configuration missing' }),
        { 
          status: 500, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        }
      )
    }

    const supabase = createClient(supabaseUrl, supabaseServiceKey)

    // Query stores table to get owner email
    console.log(`🔍 Looking for store: ${storeName}`)
    const { data: storeData, error: storeError } = await supabase
      .from('stores')
      .select('owner_email, name')
      .eq('name', storeName)
      .single()

    if (storeError || !storeData) {
      console.error('Store lookup error:', storeError)
      return new Response(
        JSON.stringify({ 
          error: `Store not found: ${storeName}`,
          details: storeError?.message 
        }),
        { 
          status: 404, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        }
      )
    }

    const store = storeData as StoreRecord
    console.log(`✅ Found store: ${store.name}, owner: ${store.owner_email}`)

    if (!store.owner_email) {
      return new Response(
        JSON.stringify({ 
          error: `Store owner email not found for: ${storeName}` 
        }),
        { 
          status: 404, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        }
      )
    }

    // Send email notification
    try {
      const emailResult = await sendEmailViaEmailJS(
        store.owner_email,
        customerName,
        productName,
        quantity,
        storeName
      )

      console.log('✅ Email sent successfully:', emailResult)

      const response = {
        success: true,
        message: 'Order notification sent successfully',
        details: {
          customerName,
          productName,
          quantity,
          storeName,
          storeOwnerEmail: store.owner_email,
          emailResult
        }
      }

      return new Response(
        JSON.stringify(response),
        { 
          status: 200, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        }
      )

    } catch (emailError) {
      console.error('❌ Email sending failed:', emailError)
      return new Response(
        JSON.stringify({ 
          error: 'Failed to send email notification',
          message: emailError.message,
          details: {
            customerName,
            productName,
            quantity,
            storeName,
            storeOwnerEmail: store.owner_email
          }
        }),
        { 
          status: 500, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        }
      )
    }

  } catch (error) {
    console.error('❌ Error in order-notification function:', error)
    
    return new Response(
      JSON.stringify({ 
        error: 'Internal server error',
        message: error.message 
      }),
      { 
        status: 500, 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      }
    )
  }
})
